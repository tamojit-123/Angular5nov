import { createComponent } from '@angular/compiler/src/core';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CreateComponent } from './about/create/create.component';
import { DetailsComponent } from './about/details/details.component';
import { AuthGuard } from './auth.guard';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { OrderComponent } from './order/order.component';

const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"About",
    children:[
      {
        path:"",
        component:AboutComponent
       },
       {
        path:"Create",
        component:CreateComponent
       },
       {
        path:"Details",
        component:DetailsComponent
       },
    ]
    
  },
  {
path:"Login",
component:LoginComponent
  },
  {
path:"Order",
canActivate:[AuthGuard],
component:OrderComponent
  },
  {
    path:"Contact",
    component:ContactComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
