export class Student
{
    id:number=0;
    name:string='';
    stream:string='';
}