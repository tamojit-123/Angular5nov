import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Hero } from '../hero';
import {HEROES} from '../mock-heores';
import {DatetimeserviceService} from '../datetimeservice.service';


@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css']
})
export class HeroComponent implements OnInit {
  heroes=HEROES;
  hero:Hero={
    id:101,
    name:'Gaurav'
  };
  @Input() childmsg:string='';

  @Output() myoutput:EventEmitter<string>=new EventEmitter();
  outputmsg:string="I am child component";
sendmsg()
{
 this.myoutput.emit(this.outputmsg); 
}
  constructor(private datetime:DatetimeserviceService) { }
  todayDate:any;
  save()
  {
    this.todayDate=this.datetime.showTodayDate();
  }

  ngOnInit(): void {
  }

}
