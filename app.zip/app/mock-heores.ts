import {Hero}from './hero';

export const HEROES:Hero[]=[
    {id:1,name:"Shashank"},
    {id:2,name:"Sonu"},
    {id:3,name:"Ankur"}
];