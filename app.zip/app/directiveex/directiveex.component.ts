import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directiveex',
  templateUrl: './directiveex.component.html',
  styleUrls: ['./directiveex.component.css']
})
export class DirectiveexComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  people:any[]=[
    {
      "name":"Sam",
      "age":30,
      "country":"India"
    },
    {
      "name":"John",
      "age":25,
      "country":"Pakistan"
    },
    {
      "name":"Johny",
      "age":20,
      "country":"Pakistan"
    },
    {
      "name":"Michael",
      "age":40,
      "country":"Nepal"
    }
   ];
}
