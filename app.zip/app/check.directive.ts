import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appCheck]'
})
export class CheckDirective {

  constructor(private templateref:TemplateRef<any>,
    private viewcontainer:ViewContainerRef) { }

    @Input() set appCheck(data:boolean)
    {
      this.viewcontainer.clear();
    
    if(data)
    {
      console.log(data);
      //insert the template into container
      this.viewcontainer.createEmbeddedView(this.templateref);

    }
}
}