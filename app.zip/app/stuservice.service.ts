import { Injectable } from '@angular/core';
import { Student } from './stu';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StuserviceService {

  constructor(private httpClient:HttpClient) { }
  private api:string="http://localhost:3000/stu";

  getAllStu(): Observable<Array<Student>>{
    return this.httpClient.get<Array<Student>>(this.api);

  }
addStu(stu:Student):Observable<Student>{
  return this.httpClient.post<Student>(this.api,stu);
}
}
