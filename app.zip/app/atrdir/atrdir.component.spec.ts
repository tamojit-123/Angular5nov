import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AtrdirComponent } from './atrdir.component';

describe('AtrdirComponent', () => {
  let component: AtrdirComponent;
  let fixture: ComponentFixture<AtrdirComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AtrdirComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AtrdirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
