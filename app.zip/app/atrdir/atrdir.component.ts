import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atrdir',
  templateUrl: './atrdir.component.html',
  styleUrls: ['./atrdir.component.css']
})
export class AtrdirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
items=[
  {name:"APPLE",type:"fruit"},
  {name:"BANANA",type:"fruit"},
  {name:"CARROT",type:"vegetable"},

];
getcolor(type:any)
{
if(type=='fruit')
{
  return 'red';
}
else 
{
  return 'yellow';
}
}
}
