import { Component, OnInit } from '@angular/core';
import {Observable, of,interval} from 'rxjs';
import {reduce, filter, take} from 'rxjs/operators';


@Component({
  selector: 'app-rxjxex',
  templateUrl: './rxjxex.component.html',
  styleUrls: ['./rxjxex.component.css']
})
export class RxjxexComponent implements OnInit {

  constructor() { 
    //creating a stream of values
    let test=of(1,2,3,4,5,6,7,8);
    let case1=test.pipe(
      filter(x=>x%2===0),
      reduce((acc,one)=>acc+one,0)
    )
    case1.subscribe(x=>console.log(x));
  }

  ngOnInit(): void {
    const numbers=interval(1000);
    const take1=numbers.pipe(take(8));
    take1.subscribe(value=>console.log(value));

    const simpleobservable=new Observable((observer)=>
    {
      observer.next(10)
      observer.next(30)
      observer.next(50)
      observer.next("Hello")
      observer.complete()
    })

    simpleobservable.subscribe(
      {
        next(x){console.log("Value:"+x)},
        error(err){console.log("ERrror Occured")},
        complete(){console.log("completed");}

      }
    );
   const observable1=new Observable(function subscribe(subscriber){
     const id=setInterval(()=>{
       subscriber.next("Hii")
     },1000);
   }
   
   ) ;
observable1.subscribe(
  {
    next(x){console.log("Value:"+x)},
    error(err){console.log("ERrror Occured")},
    complete(){console.log("completed")}
  }
)


  }

}
