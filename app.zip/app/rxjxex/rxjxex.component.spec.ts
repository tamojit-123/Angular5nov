import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RxjxexComponent } from './rxjxex.component';

describe('RxjxexComponent', () => {
  let component: RxjxexComponent;
  let fixture: ComponentFixture<RxjxexComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RxjxexComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RxjxexComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
