import { CheckDirective } from './check.directive';

describe('CheckDirective', () => {
  it('should create an instance', () => {
    const directive = new CheckDirective();
    expect(directive).toBeTruthy();
  });
});
