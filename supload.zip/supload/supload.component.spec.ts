import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuploadComponent } from './supload.component';

describe('SuploadComponent', () => {
  let component: SuploadComponent;
  let fixture: ComponentFixture<SuploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
