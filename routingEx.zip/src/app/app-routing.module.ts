import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { CreateComponent } from './about/create/create.component';
import { DetailsComponent } from './about/details/details.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"About",
    children:[
      {
        path:"",
        component:AboutComponent
      },
      {
        path:"Details",
        component:DetailsComponent
      },
      {
        path:"Create",
        component:CreateComponent
      }
    ]
  },
  {
    path:"Contact",
    component:ContactComponent
  },
  {
    path:"NotFound",
    component:NotFoundComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
