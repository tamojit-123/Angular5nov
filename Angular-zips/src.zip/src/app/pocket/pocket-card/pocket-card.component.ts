import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pocket-card',
  templateUrl: './pocket-card.component.html',
  styleUrls: ['./pocket-card.component.css']
})
export class PocketCardComponent implements OnInit {

  @Output()
  metadata: any= new EventEmitter<any>();

  constructor() { }

  ngOnInit(): void {
    this.metadata = {
    //   target:"http://www.bbc.com",
      image:"../assets/pocket.png"
    }
  }

}
