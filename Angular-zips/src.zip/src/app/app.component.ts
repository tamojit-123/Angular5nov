import { Component, OnInit } from '@angular/core';
import { PocketService } from './pocket/pocket.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  pocket: any = {};
  targetUrl: string = "";
  mypocket : any =[];

  constructor(private pocketService: PocketService) {
    this.pocketService.getAllPockets().subscribe((data)=>
    {
      this.mypocket=data;
      console.log(this.mypocket);
    },
    (err)=>{
      console.log("Error while fetching the data");
    })
  }

  ngOnInit() {
    
  }

  //below code does not need debugging
  add() {
    this.pocketService.scrape({ target: this.targetUrl }).subscribe((data) => {
      this.pocket[data.url] = data;
      this.targetUrl = '';

      this.pocketService.addPockets(this.pocket).subscribe(
        (data)=>{
          this.mypocket.push(data);
        },(err)=>{console.log("error while fetching data")}
      )
      console.log(this.mypocket);
    })

    
  }

}
